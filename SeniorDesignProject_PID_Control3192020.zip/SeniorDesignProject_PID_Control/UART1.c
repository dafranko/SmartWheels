#include "UART1.h" 
#include "tm4c123gh6pm.h"




unsigned char UART1_InChar(){
	while((UART1_FR_R&UART_FR_RXFE) != 0);
	return ((unsigned char) (UART1_DR_R&0xFF));
}

unsigned char UART1_InCharNonBlocking(void){
	if ((UART1_FR_R&UART_FR_RXFE) != 0){while((UART1_FR_R&UART_FR_RXFE) != 0);}
	return ((unsigned char) (UART1_DR_R&0xFF));
}


void UART1_OutChar(unsigned char data){
	while((UART1_FR_R&UART_FR_TXFF) != 0);
	UART1_DR_R = data;
}

void UART1_transmit_String(const char *MessageString){
	
	while( *MessageString){
		
		UART1_OutChar(*MessageString);
		MessageString++;
	}
}



void UART1_INIT(){unsigned volatile long delay;
	SYSCTL_RCGC1_R |= 0x02; // Activate UART1
	SYSCTL_RCGC2_R |= 0x02; // Activate Port B
	delay = SYSCTL_RCGC2_R;
	
	UART1_CTL_R &= ~0x01; // Disable UART
	UART1_IBRD_R = 26;//17;
	UART1_FBRD_R = 2;//23; 
	UART1_LCRH_R = 0x70; //
	UART1_CTL_R |= 0x01; // enable uart
	GPIO_PORTB_AFSEL_R |= 0x03;
	GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFFFF00)+0x00000011; // configure PB0 as U0Rx, PB1 as U0Tx
	GPIO_PORTB_AMSEL_R &= ~0x03;
	GPIO_PORTB_DEN_R |= 0x03;
	
	//NVIC_PRI1_R = (NVIC_PRI1_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  //NVIC_EN0_R = 0x00000040;      // (h) enable interrupt 6 in NVIC for uart1
}




//void UART1_Handler(void){
	
//    UART1_ICR_R |= 0x01;  // acknowledge flag0
  
	
//}
