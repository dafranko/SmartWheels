#include "tm4c123gh6pm.h"


void PortC_Direction_Init(void){volatile unsigned long delay;
	
	SYSCTL_RCGC2_R 	|= 0x04;//activate clock to port c
	delay = SYSCTL_RCGC2_R;
	GPIO_PORTC_CR_R |= 0xC0;
	GPIO_PORTC_AMSEL_R &= ~0xC0;
	GPIO_PORTC_PCTL_R &= ~0xFF000000;
	GPIO_PORTC_DIR_R |= 0xC0;
	GPIO_PORTC_AFSEL_R &= ~0xC0;
	GPIO_PORTC_DEN_R |= 0xC0;
	
	GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
}

