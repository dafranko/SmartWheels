
void PortC_Direction_Init(void);
