#include "tm4c123gh6pm.h"

void PortB_Direction_Init(void){volatile unsigned long delay;
	
	SYSCTL_RCGC2_R 	|= 0x02;//activate clock to port b
	delay = SYSCTL_RCGC2_R;
	GPIO_PORTB_CR_R |= 0xF0;
	GPIO_PORTB_AMSEL_R &= ~0xF0;
	GPIO_PORTB_PCTL_R &= ~0xFFFF0000;
	GPIO_PORTB_DIR_R |= 0xF0;
	GPIO_PORTB_AFSEL_R &= ~0xF0;
	GPIO_PORTB_DEN_R |= 0xF0;
	GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
	
}

