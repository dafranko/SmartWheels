#include "tm4c123gh6pm.h"
#include "PortC_6_7_Init.h"

void PortC_Direction_Init(void){volatile unsigned long delay;
	
	SYSCTL_RCGC2_R 	|= 0x04;//activate clock to port c
	delay = SYSCTL_RCGC2_R;
	GPIO_PORTC_CR_R |= 0xC0;
	GPIO_PORTC_AMSEL_R &= ~0xC0;
	GPIO_PORTC_PCTL_R &= ~0xFF000000;
	GPIO_PORTC_DIR_R |= 0xC0;
	GPIO_PORTC_AFSEL_R &= ~0xC0;
	GPIO_PORTC_DEN_R |= 0xC0;
//	GPIO_PORTC_DATA_R &= ~0xC0;

	
/*	GPIO_PORTC_IS_R &= ~0xC0;     //  is edge-sensitive
  GPIO_PORTC_IBE_R &= ~0xC0;    //  not both edges
  GPIO_PORTC_IEV_R &= ~0xC0;    //  rising edge event
	
	NVIC_EN0_R = 0x00000004;      // (h) enable interrupt 2 in NVIC
*/

	
}

