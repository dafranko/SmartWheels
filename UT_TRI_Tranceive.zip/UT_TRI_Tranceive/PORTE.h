
void PORTE_Init(void);                   
