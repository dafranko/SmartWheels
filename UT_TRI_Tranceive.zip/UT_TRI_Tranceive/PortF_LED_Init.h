
#define YELLOW    0x0A
#define PINK      0x06
#define WHITE     0x0E
#define DARK 			0x00
#define RED				0x02
#define BLUE			0x04
#define GREEN			0x08
#define SKY_BLUE	0x0C

void PORTF_INIT(void);
