#include "tm4c123gh6pm.h"
#include "stdint.h"
#include "stdlib.h"
#include "UART0.h"
#include "UART1.h"
#include "TIMER3A.h"
#include "TIMER2A.h"
#include "PortC_pwm_init.h"
#include "PortC_6_7_Init.h"
#include "PortF_LED_Init.h"
#include "PORTE.h"
#include "PLL.h"
#include <math.h>
void PORTE_Init(void);                         
int power(int x, unsigned int y);
unsigned int hc_sr04_conv(int e);

#define CR 0x0d
#define BS 0x08


unsigned int inc = 0;

int main(void){ unsigned char data;
 	PLL_Init();
	PORTF_INIT();
	UART0_INIT();
	UART1_INIT();
	PortC_Direction_Init();
	timer2_Init();
	TIMER2_CTL_R = 0x00000001;    


  while(1){
			data = UART1_InChar();
			if(data == 'A'){
											inc = 0;
											GPIO_PORTC_DATA_R |= 0xC0;
											while(1){
											if(inc == 10){GPIO_PORTC_DATA_R &= ~0xC0;break;}
											}	
			}
			
			UART0_OutChar(data);
		
	}
}


void Timer2A_Handler(void){//1 milisecond	
	inc += 1;
	TIMER2_ICR_R = 0x01;			// clear interrupt flag	
}	


/*

void Timer3A_Handler(void){//100 milisecond
	volatile uint32_t readback;	

	
	GPIO_PORTC_DATA_R &= ~0xC0;	
	inc = 0;	
	UART1_OutChar('A');
	GPIO_PORTC_DATA_R |= 0xC0;
	TIMER3_ICR_R = 0x01;			// clear interrupt flag	
	readback = TIMER3_ICR_R;
	
}	



//if(inc== 10){//at least 10 miliseconds have passed meaning we should disable the pwm
		//GPIO_PORTC_DATA_R &= ~0xC0;
	//}
	


unsigned int hc_sr04_conv(int e){
	
	unsigned int y;
	y = 77850*e - 6237000;

	
	return y/1000;
	
	
	
}
int power(int x, unsigned int y) 
{ 
		int holder = 1;
		int i = 0;
    if (y == 0){
        return 1;} 
    else{
			for(i = 0; i < y; i = i + 1){
			holder*=x;
			}
			return holder;
		}
} */

