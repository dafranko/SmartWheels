#include "TIMER2A.h" 
#include "tm4c123gh6pm.h"


void timer2_Init(void){
  SYSCTL_RCGCTIMER_R |= 0x04;   // 0) activate timer2
  TIMER2_CTL_R = 0x00000000;    // 1) disable timer2A during setup
  TIMER2_CFG_R = 0x00000000;    // 2) configure for 32-bit mode
  TIMER2_TAMR_R = 0x00000002;   // 3) configure for ONE SHOT mode, 
  TIMER2_TAILR_R = (80)-1;    // 4) reload value
  TIMER2_TAPR_R = 0;            // 5) bus clock resolution
  TIMER2_ICR_R = 0x00000001;    // 6) clear timer2A timeout flag
  TIMER2_IMR_R = 0x00000001;    // 7) arm timeout interrupt
 // NVIC_PRI5_R = (NVIC_PRI5_R&0x00FFFFFF)|0x80000000; // 8) priority 4
// interrupts enabled in the main program after all devices initialized
// vector number 39, interrupt number 23
  NVIC_EN0_R = 1<<23;           // 9) enable IRQ 23 in NVIC
  //TIMER2_CTL_R = 0x00000001;    // 10) enable timer2A
}

/*

void timer2_Init(void){
	
	SYSCTL_RCGCTIMER_R |= 4;	// enable clock to Timer 2
	TIMER2_CTL_R = 0;					// disable Timer2 during config
	TIMER2_CFG_R = 0x00;			// 32-bit mode
	TIMER2_TAMR_R = 0x02;			// one-shot up-counter
	TIMER2_TAILR_R = 16000000-1;;    // 4) reload value
  TIMER2_TAPR_R = 0;            // 5) bus clock resolution
	TIMER2_ICR_R = 0x01;			// clear Timer3A timeout flag
	TIMER2_IMR_R |= 0x01;			// enable Timer3A timeout interrupt
	TIMER2_CTL_R |= 0x01;			// enable Timer3A after config
	// PRI5[31:29] set interrupt PRIORITY = 4
//	NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0x80000000;		// Priority 4

	//NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0xC0000000;		// Priority 6
	NVIC_EN0_R |= 0x00800000;	
	
	
	
	
}

*/
