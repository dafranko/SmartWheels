
#include "tm4c123gh6pm.h"

void PORTC_PWM0_GEN3_AB_Init(void){volatile unsigned long delay;

	//Port C Init
	SYSCTL_RCGC2_R |= 0x04;//activate clock to port c
	delay = SYSCTL_RCGC2_R;
	GPIO_PORTC_CR_R |= 0x30;//allows changes to PC4 and PC5
	GPIO_PORTC_AMSEL_R &= ~0x30;//no analog funct. on PC4 and PC5
	GPIO_PORTC_PCTL_R = (GPIO_PORTC_PCTL_R & ~0x00FF0000) | 0x00440000;//configure for pwm
	GPIO_PORTC_DIR_R |= 0x30;
	GPIO_PORTC_AFSEL_R |= 0x30;
	GPIO_PORTC_DEN_R |= 0x30;
	
	//PWM
	
	SYSCTL_RCGCPWM_R |= 0x01; //activate clock to pwm0
	SYSCTL_RCC_R = (SYSCTL_RCC_R & ~0x000E0000) | 0x00100000;// Setting Use PWM div, making PWM div 000, so it divides by 2
	PWM0_3_CTL_R = 0; //disable for configuration
	PWM0_3_GENA_R = 0x8C;//low on load, high when it reaches compareA value
	PWM0_3_GENB_R = 0x80C;//low on load, high when it reaches compareB	value
	PWM0_3_LOAD_R = 40000 - 1;//cycles
	PWM0_3_CMPA_R = 39998; //count value when the output rises
	PWM0_3_CMPB_R = 39998; //count value when output rises
	PWM0_3_CTL_R |= 0x01;//count down, pwm on
	PWM0_ENABLE_R |= 0xC0;//output 6 - PC4, and output 7 PC5	
	
}


void PC4_PWM(unsigned long H){//left motor
	
	PWM0_3_CMPA_R = H - 1;

}
	

void PC5_PWM(unsigned long H){//right motor
	
	PWM0_3_CMPB_R = H - 1;

}
