#include "tm4c123gh6pm.h"

void UART1_INIT(void);
void UART1_OutChar(unsigned char);
unsigned char UART1_InChar(void);
void UART1_transmit_String(const char *MessageString);
void UART1_transmit_Integer(unsigned int INT);
void UART1_InString(char *bufPt, unsigned short max);
unsigned char UART1_InCharNonBlocking(void);
void UART1_InString(char *bufPt, unsigned short max);

