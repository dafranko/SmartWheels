#include "TIMER3A.h" 
#include "tm4c123gh6pm.h"


void timer3_Init(void){
	
	// Configure Timer3
	SYSCTL_RCGCTIMER_R |= 0x08;	// enable clock to Timer 2
	TIMER3_CTL_R = 0;					// disable Timer2 during config
	TIMER3_CFG_R = 0x00;			// 16-bit mode
	TIMER3_TAMR_R = 0x02;			// periodic up-counter
	TIMER3_TAILR_R = (4800000)-1;		//100 miliseconds
	TIMER3_TAPR_R = 0;			// 16MHz/250 64kHz
	TIMER3_ICR_R = 0x01;			// clear Timer3A timeout flag
	TIMER3_CTL_R |= 0x01;			// enable Timer3A after config
	// PRI5[31:29] set interrupt PRIORITY = 4
//	NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0x80000000;		// Priority 4
	//NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0xC0000000;		// Priority 6
	NVIC_EN1_R |= 0x00000008;	
	TIMER3_IMR_R |= 0x01;			// enable Timer3A timeout interrupt

	
	
	
}

