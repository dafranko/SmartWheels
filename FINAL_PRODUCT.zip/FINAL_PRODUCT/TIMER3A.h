#include "tm4c123gh6pm.h"

void timer3_Init(void);

void Timer3A_Handler(void);
