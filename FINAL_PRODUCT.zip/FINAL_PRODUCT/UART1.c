#include "UART1.h" 
#include "tm4c123gh6pm.h"

#define CR 0x0d
#define BS 0x08


void UART1_InString(char *bufPt, unsigned short max) {
int length=0;
char character;
  character = UART1_InChar();
  while(character != CR){
    if(character == BS){
      if(length){
        bufPt--;
        length--;
        //UART1_OutChar(BS);
      }
    }
    else if(length < max){
      *bufPt = character;
      bufPt++;
      length++;
      //UART1_OutChar(character);
    }
    character = UART1_InChar();
  }
	*bufPt = 0;
}


void UART1_transmit_Integer(unsigned int INT){
	
	volatile int array_l[8];
	//TIMER2_CTL_R = 1;					// disable Timer2 during config
	int var = INT,i = 0;
	volatile int *ptrl = array_l;
	while(1){if(var == 0){ break;}var/=10;i++;}//get number of characters in array
	var = INT;
	array_l[i+1] = CR;
	while(i!=0){	array_l[i] = var%10;var = var/10;i--;}//store integers into array
	while( *ptrl!=CR){UART1_OutChar((*ptrl)+48);ptrl++;}//output array integers in ascii
	
	
}


unsigned char UART1_InChar(){
	while((UART1_FR_R&UART_FR_RXFE) != 0);
	return ((unsigned char) (UART1_DR_R&0xFF));
}

unsigned char UART1_InCharNonBlocking(void){
	if ((UART1_FR_R&UART_FR_RXFE) != 0){while((UART1_FR_R&UART_FR_RXFE) != 0);}
	return ((unsigned char) (UART1_DR_R&0xFF));
}


void UART1_OutChar(unsigned char data){
	while((UART1_FR_R&UART_FR_TXFF) != 0);
	UART1_DR_R = data;
}

void UART1_transmit_String(const char *MessageString){
	
	while( *MessageString){
		
		UART1_OutChar(*MessageString);
		MessageString++;
	}
}

//16MHZ										//80MHZ
//104 10 9600							//520 53
//26  2  38400						//130	13
//17  23 57600						//86	51
//8   43 115200						//43	25
void UART1_INIT(){unsigned volatile long delay;
	SYSCTL_RCGC1_R |= 0x02; // Activate UART1
	SYSCTL_RCGC2_R |= 0x02; // Activate Port B
	delay = SYSCTL_RCGC2_R;
	
	UART1_CTL_R &= ~0x01; // Disable UART
	UART1_IBRD_R = 86;//
	UART1_FBRD_R = 51; //
	UART1_LCRH_R = 0x70; //
	UART1_CTL_R |= 0x01; // enable uart
	GPIO_PORTB_AFSEL_R |= 0x03;
	GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFFFF00)+0x00000011; // configure PB0 as U0Rx, PB1 as U0Tx
	GPIO_PORTB_AMSEL_R &= ~0x03;
	GPIO_PORTB_DEN_R |= 0x03;
	
	//NVIC_PRI1_R = (NVIC_PRI1_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  //NVIC_EN0_R = 0x00000040;      // (h) enable interrupt 6 in NVIC for uart1
}




//void UART1_Handler(void){
	
//    UART1_ICR_R |= 0x01;  // acknowledge flag0
  
	
//}
