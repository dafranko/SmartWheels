#include "tm4c123gh6pm.h"

void UART2_INIT(void); 
void UART2_OutChar(unsigned char);
unsigned char UART2_InChar(void);
void UART2_transmit_String(const char *MessageString);
unsigned char UART2_InCharNonBlocking(void);
void UART2_transmit_dec(int dec);
void UART2_InString(char *bufPt, unsigned short max);
void UART2_transmit_Integer(unsigned int INT);