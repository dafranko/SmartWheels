#include "tm4c123gh6pm.h"





void PORTE_Init(void){                          
  SYSCTL_RCGC2_R |= 0x00000010; // (a) activate clock for port F
  GPIO_PORTE_DIR_R &= ~0x03;    // (c) make PF4 in (built-in button)
  GPIO_PORTE_AFSEL_R &= ~0x03;  //     disable alt funct on PF4
  GPIO_PORTE_DEN_R |= 0x03;     //     enable digital I/O on PF4   
  GPIO_PORTE_PCTL_R &= ~0x000000FF; // configure PF4 as GPIO
  GPIO_PORTE_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTE_PUR_R |= 0x03;     //     enable weak pull-up on PF4
  GPIO_PORTE_IS_R &= ~0x03;     // (d) PF4 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x03;    //     PF4 is not both edges
  GPIO_PORTE_IEV_R &= ~0x03;    //     PF4 falling edge event
  GPIO_PORTE_ICR_R = 0x03;      // (e) clear flag4
  GPIO_PORTE_IM_R |= 0x03;      // (f) arm interrupt on PF4
  NVIC_PRI1_R = (NVIC_PRI1_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x00000010;      // (h) enable interrupt 30 in NVIC
//  EnableInterrupts();           // (i) Clears the I bit
}