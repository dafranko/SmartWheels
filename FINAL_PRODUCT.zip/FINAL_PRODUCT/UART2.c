#include "UART2.h" 
#include "tm4c123gh6pm.h"




unsigned char UART2_InChar(){
	while((UART2_FR_R&UART_FR_RXFE) != 0);
	return ((unsigned char) (UART2_DR_R&0xFF));
}

unsigned char UART2_InCharNonBlocking(void){
	if ((UART2_FR_R&UART_FR_RXFE) != 0){while((UART2_FR_R&UART_FR_RXFE) != 0);}
	return ((unsigned char) (UART2_DR_R&0xFF));
}


void UART2_OutChar(unsigned char data){
	while((UART2_FR_R&UART_FR_TXFF) != 0);
	UART2_DR_R = data;
}

void UART2_transmit_String(const char *MessageString){
	
	while( *MessageString){
		
		UART2_OutChar(*MessageString);
		MessageString++;
	}
}



void UART2_INIT(){unsigned volatile long delay;
	SYSCTL_RCGC1_R |= 0x02; // Activate UART2
	SYSCTL_RCGC2_R |= 0x08; // Activate Port D
	delay = SYSCTL_RCGC2_R;
	
	UART2_CTL_R &= ~0x01; // Disable UART
	UART2_IBRD_R = 26;//17;
	UART2_FBRD_R = 2;//23; 
	UART2_LCRH_R = 0x70; //
	UART2_CTL_R |= 0x01; // enable uart
	GPIO_PORTD_AFSEL_R |= 0xC0;
	GPIO_PORTD_PCTL_R = (GPIO_PORTB_PCTL_R&0x00FFFFFF)+0x11000000; // configure PB0 as U0Rx, PB1 as U0Tx
	GPIO_PORTD_AMSEL_R &= ~0xC0;
	GPIO_PORTD_DEN_R |= 0xC0;
	
	//NVIC_PRI1_R = (NVIC_PRI1_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  //NVIC_EN0_R = 0x00000040;      // (h) enable interrupt 6 in NVIC for UART2
}




//void UART2_Handler(void){
	
//    UART2_ICR_R |= 0x01;  // acknowledge flag0
  
	
//}
