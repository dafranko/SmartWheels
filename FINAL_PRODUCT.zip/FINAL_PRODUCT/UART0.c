#include "UART0.h" 
#include "tm4c123gh6pm.h"
#define CR 0x0d
#define BS 0x08
void UART0_InString(char *bufPt, unsigned short max) {
int length=0;
char character;
  character = UART0_InChar();
  while(character != CR){
    if(character == BS){
      if(length){
        bufPt--;
        length--;
        UART0_OutChar(BS);
      }
    }
    else if(length < max){
      *bufPt = character;
      bufPt++;
      length++;
      UART0_OutChar(character);
    }
    character = UART0_InChar();
  }
  *bufPt = 0;
}

unsigned char UART0_InChar(){
	while((UART0_FR_R&UART_FR_RXFE) != 0);
	return ((unsigned char) (UART0_DR_R&0xFF));
}

unsigned char UART0_InCharNonBlocking(void){
// as part of Lab 11, modify this program to use UART0 instead of UART1
  if((UART0_FR_R&UART_FR_RXFE) == 0){
    return((unsigned char)(UART0_DR_R&0xFF));
  } else{
    return 0;
  }
}

void UART0_OutChar(unsigned char data){
	while((UART0_FR_R&UART_FR_TXFF) != 0);
	UART0_DR_R = data;
}

void UART0_transmit_String(const char *MessageString){
	
	while( *MessageString){
		
		UART0_OutChar(*MessageString);
		MessageString++;
	}
}

void UART0_transmit_Integer(unsigned int INT){
	
	volatile int array_l[8];
	//TIMER2_CTL_R = 1;					// disable Timer2 during config
	int var = INT,i = 0;
	volatile int *ptrl = array_l;
	while(1){if(var == 0){ break;}var/=10;i++;}//get number of characters in array
	var = INT;
	array_l[i+1] = CR;
	while(i!=0){	array_l[i] = var%10;var = var/10;i--;}//store integers into array
	while( *ptrl!=CR){UART0_OutChar((*ptrl)+48);ptrl++;}//output array integers in ascii
	
	
}


void UART0_transmit_dec(int dec){
	
	int count = 0; 
	int n = dec;
	int num[10]; 
	int i = 0;
    while (n != 0) { 
        n = n / 10; 
        ++count; 
    } 
	
		
		
	while(i <= count){
			num[count - i] = (dec%10)+48;
			dec /= 10;
		i++;
	}
	i = 0;
	while(i <= count){
			UART0_OutChar(num[i+1]);//i+48
			i++;
	}
	
	
	
	
	/*
		do{
		UART0_OutChar((dec%10)+48);
		dec /= 10;
	}while(dec > 0);
	*/
	
	
}

//16MHZ										//80MHZ
//104 10 9600							//520 53
//26  2  38400						//130	13
//17  23 57600						//86	51
//8   43 115200						//43	25
void UART0_INIT(){unsigned volatile long delay;
	SYSCTL_RCGC1_R |= 0x01; // Activate UART0
	SYSCTL_RCGC2_R |= 0x01; // Activate Port A
	delay = SYSCTL_RCGC2_R;
	//while((SYSCTL_PRGPIO_R&0x02) == 0){};
	UART0_CTL_R &= ~0x01; // Disable UART
	UART0_IBRD_R = 86;//26;//8; // 115200 baud,  104 for 9600 baud does not work
	UART0_FBRD_R = 51;//2;//43; // 10;
	UART0_LCRH_R = 0x70; //8bit no parity, one stop, fifos
	UART0_CTL_R |= 0x01; // enable uart
	GPIO_PORTA_AFSEL_R |= 0x03;
	GPIO_PORTA_PCTL_R &= (GPIO_PORTA_PCTL_R&0xFFFFFF00)+0x00000011; // configure PA0 as U0Rx, PA1 as U0Tx
	GPIO_PORTA_AMSEL_R &= ~0x03;
	GPIO_PORTA_DEN_R |= 0x03;
}
