#include "tm4c123gh6pm.h"

void PORTC_PWM0_GEN3_AB_Init(void);

void PC4_PWM(unsigned long H);
	

void PC5_PWM(unsigned long H);

