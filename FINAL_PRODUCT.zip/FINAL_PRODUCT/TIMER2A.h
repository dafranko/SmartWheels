#include "tm4c123gh6pm.h"

void timer2_Init(void);

void Timer2A_Handler(void);
