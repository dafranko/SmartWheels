#include "tm4c123gh6pm.h"
#include "stdint.h"
#include "stdlib.h"
#include "UART0.h"
#include "UART1.h"
#include "TIMER3A.h"
#include "TIMER2A.h"
#include "PortC_pwm_init.h"
#include "PortC_6_7_Init.h"
#include "PortF_LED_Init.h"
#include "PORTE.h"
#include "PLL.h"
#include <math.h>
void PORTE_Init(void);                         
int power(int x, unsigned int y);
unsigned int hc_sr04_conv(int e);

#define CR 0x0d
#define BS 0x08


unsigned int inc = 0,e0 = 0,e1 = 0,e2 = 0,e3 = 0;

int main(void){ 
 	PLL_Init();
	
	PORTF_INIT();
	UART0_INIT();
	UART1_INIT();
	PORTE_Init();    

	//PORTC_PWM0_GEN3_AB_Init();
	PortC_Direction_Init();
	timer3_Init();
	timer2_Init();	
	TIMER2_CTL_R |= 0x00000001;


  while(1){
			if(inc == 7900){GPIO_PORTC_DATA_R |= 0xC0;}
			if(inc == 7910){GPIO_PORTC_DATA_R &= ~0xC0;}
		
	}
}










void GPIOPortE_Handler(void){
	
	if(GPIO_PORTE_RIS_R&0x01){  
    GPIO_PORTE_ICR_R |= 0x01;  
		e0 = ((inc-7910)*343)/2000;
	}
		
  if(GPIO_PORTE_RIS_R&0x02){ 
    GPIO_PORTE_ICR_R |= 0x02;	
		e1 = ((inc-7910)*343)/2000;

  }	
	
	
  if(GPIO_PORTE_RIS_R&0x04){ 
    GPIO_PORTE_ICR_R |= 0x04;		
		e2 = ((inc-7910)*343)/2000;

  }	
	if(GPIO_PORTE_RIS_R&0x08){ 
    GPIO_PORTE_ICR_R |= 0x08;		
		e3 = ((inc-7910)*343)/2000;

	}
}










void Timer3A_Handler(void){//100 milisecond
	volatile uint32_t readback;	
	/*
#define YELLOW    0x0A
#define PINK      0x06
#define WHITE     0x0E
#define DARK 			0x00
#define RED				0x02
#define BLUE			0x04
#define GREEN			0x08
#define SKY_BLUE	0x0C
	*/
	/////////////////////////////
	//not accurate after 10 inches y = 275.5034 + (82.12992 - 275.5034)/(1 + (x/6.924857)^1.956264)
	//better y = .00004729*(x^2)+0.05909*x-4.623
	e0=hc_sr04_conv(e0);
	e1=hc_sr04_conv(e1);
//	e2=hc_sr04_conv(e2);
	e3=hc_sr04_conv(e3);
	if(e0<35000){GPIO_PORTF_DATA_R |= RED;}
	else{GPIO_PORTF_DATA_R &= ~RED;}
	if(e1<35000){GPIO_PORTF_DATA_R |= GREEN;}
	else{GPIO_PORTF_DATA_R &= ~GREEN;}
	if(e3<35000){GPIO_PORTF_DATA_R |= BLUE;}
	else{GPIO_PORTF_DATA_R &= ~BLUE;}
		
	
		UART0_transmit_String("PORTE0: ");		
		UART0_transmit_Integer(e0);
		UART0_transmit_String("\t");
		
		UART0_transmit_String("PORTE1: ");		
		UART0_transmit_Integer(e1);
		UART0_transmit_String("\t");
/*	
		UART0_transmit_String("PORTE2: ");		
		UART0_transmit_Integer(e2);
		UART0_transmit_String("\t");
	*/
		UART0_transmit_String("PORTE3: ");		
		UART0_transmit_Integer(e3);
		UART0_transmit_String("\t");
	
		UART0_transmit_String("\r\n");
		e0=e1=e2=e3=0;
	
	
	///////////////////////////////
	GPIO_PORTC_DATA_R &= ~0xC0;	
	inc = 0;	
	UART1_OutChar('A');
	TIMER3_ICR_R = 0x01;			// clear interrupt flag	
	readback = TIMER3_ICR_R;
	
}	



//if(inc== 10){//at least 10 miliseconds have passed meaning we should disable the pwm
		//GPIO_PORTC_DATA_R &= ~0xC0;
	//}
	
void Timer2A_Handler(void){//1 milisecond	
	inc += 1;
	TIMER2_ICR_R = 0x01;			// clear interrupt flag	
}	



void PORTE_Init(void){                          
  SYSCTL_RCGC2_R |= 0x00000010; // (a) activate clock for port E
  GPIO_PORTE_DIR_R &= ~0x0F;    // (c) make PF4 in (built-in button)
  GPIO_PORTE_AFSEL_R &= ~0x0F;  //     disable alt funct on PF4
  GPIO_PORTE_DEN_R |= 0x0F;     //     enable digital I/O on PF4   
  GPIO_PORTE_PCTL_R &= ~0x0000FFFF; // configure PF4 as GPIO
  GPIO_PORTE_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTE_PUR_R |= 0x0F;     //     enable weak pull-up on PF4
  GPIO_PORTE_IS_R &= ~0x0F;     // (d) PF4 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x0F;    //     PF4 is not both edges
  GPIO_PORTE_IEV_R &= ~0x0F;    //     PF4 falling edge event
  GPIO_PORTE_ICR_R = 0x0F;      // (e) clear flag4
  GPIO_PORTE_IM_R |= 0x0F;      // (f) arm interrupt on PF4
  NVIC_PRI1_R = (NVIC_PRI1_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R |= 0x00000010;      // (h) enable interrupt 4 in NVIC
//  EnableInterrupts();           // (i) Clears the I bit
}
/*
*/

unsigned int hc_sr04_conv(int e){
	
	unsigned int y;
	y = 77850*e - 6237000;

	
	return y/1000;
	
	
	
}
int power(int x, unsigned int y) 
{ 
		int holder = 1;
		int i = 0;
    if (y == 0){
        return 1;} 
    else{
			for(i = 0; i < y; i = i + 1){
			holder*=x;
			}
			return holder;
		}
} 

