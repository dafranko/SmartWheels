#include "tm4c123gh6pm.h"

void UART0_INIT(void); 
void UART0_OutChar(unsigned char);
unsigned char UART0_InChar(void);
void UART0_transmit_String(const char *MessageString);
unsigned char UART0_InCharNonBlocking(void);
void UART0_transmit_dec(int dec);
void UART0_InString(char *bufPt, unsigned short max);
