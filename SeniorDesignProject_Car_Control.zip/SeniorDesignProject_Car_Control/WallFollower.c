
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode


#include "tm4c123gh6pm.h"
#include "stdint.h"
#include "stdlib.h"
#include "UART0.h"
#include "UART1.h"
#include "PORTF.h"
#include "PORTC_PWM0_GEN3_AB.h"
//#include "PortC_Direction_Init.h"
#include "PortB_Direction_Init.h"


#define YELLOW    0x0A
#define PINK      0x06
#define WHITE     0x0E
#define DARK 			0x00
#define RED				0x02
#define BLUE			0x04
#define GREEN			0x08
#define SKY_BLUE	0x0C
#define	CR				0x0D
#define BS				0x08



int countr = 0,countl = 0;//counts the number of slots read from the encoder, 
int rpm,rpmr,rpml = 0;
int speed_reductionl,speed_reductionr;
int proportionall=0, errorl=0,proportionalr=0, errorr=0,integrall = 0, integralr = 0, error_suml, error_sumr; 
int derivativel = 0, prev_errorl = 0,derivativer = 0, prev_errorr = 0;
double kp = 2, ki = 5, kd = 9;



void Robot_Controller(unsigned char character);
void EdgeCounter_Init(void);
void timer3_Init(void);
void main_init(void);
void self_pid(void);

int main(void){
	unsigned char character;
	main_init();
  while(1){
	character = UART1_InCharNonBlocking();
	UART0_OutChar('Q');//character);
	Robot_Controller(character);
	self_pid();
	//UART0_OutChar(character);//57600
		
	}
}

void self_pid(){
	/*
	prev_errorl = errorl;
	errorl = rpml - rpm; 
	error_suml += errorl;
	proportionall = kp * errorl;
	integrall = ki * error_suml;
	derivativel = kd * (errorl - prev_errorl);
	speed_reductionl = proportionall + integrall + derivativel;
	
	prev_errorr = errorr;
	errorr = rpmr - rpm;  
	error_sumr += errorr;
	proportionalr = kp * errorr;
	integralr = ki * error_sumr;
	derivativer = kd * (errorr - prev_errorr);
	speed_reductionr = proportionalr + integralr + derivativer;
	
	
	if(speed_reductionr >39996){
		speed_reductionr = 39996;
	}
	else if(speed_reductionr > 0){
		speed_reductionr = 0;
	}
	
	if(speed_reductionl >39996){
		speed_reductionl = 39996;
	}
	else if(speed_reductionl > 0){
		speed_reductionl = 0;
	}
	
	speed_reductionl = 20000;
	speed_reductionr = 20000;
*/
}

void EdgeCounter_Init(void){                          
  SYSCTL_RCGC2_R |= 0x00000010; // (a) activate clock for port F
  GPIO_PORTE_DIR_R &= ~0x03;    // (c) make PF4 in (built-in button)
  GPIO_PORTE_AFSEL_R &= ~0x03;  //     disable alt funct on PF4
  GPIO_PORTE_DEN_R |= 0x03;     //     enable digital I/O on PF4   
  GPIO_PORTE_PCTL_R &= ~0x000000FF; // configure PF4 as GPIO
  GPIO_PORTE_AMSEL_R = 0;       //     disable analog functionality on PF
  GPIO_PORTE_PUR_R |= 0x03;     //     enable weak pull-up on PF4
  GPIO_PORTE_IS_R &= ~0x03;     // (d) PF4 is edge-sensitive
  GPIO_PORTE_IBE_R &= ~0x03;    //     PF4 is not both edges
  GPIO_PORTE_IEV_R &= ~0x03;    //     PF4 falling edge event
  GPIO_PORTE_ICR_R = 0x03;      // (e) clear flag4
  GPIO_PORTE_IM_R |= 0x03;      // (f) arm interrupt on PF4
  NVIC_PRI1_R = (NVIC_PRI1_R&0xFFFFFFFF)|0x00000000; // (g) priority 5
  NVIC_EN0_R = 0x00000010;      // (h) enable interrupt 30 in NVIC
  EnableInterrupts();           // (i) Clears the I bit
}
void GPIOPortE_Handler(void){
	
	if(GPIO_PORTE_RIS_R&0x01){  // SW2 touch
    GPIO_PORTE_ICR_R |= 0x01;  // acknowledge flag0
		countr +=1;
  }
  if(GPIO_PORTE_RIS_R&0x02){  // SW1 touch
    GPIO_PORTE_ICR_R |= 0x02;  // acknowledge flag4
		countl +=1;
  }
	
}

void timer3_Init(void){
	
	// Configure Timer3
	SYSCTL_RCGCTIMER_R |= 8;	// enable clock to Timer 2
	TIMER3_CTL_R = 0;					// disable Timer2 during config
	TIMER3_CFG_R = 0x04;			// 16-bit mode
	TIMER3_TAMR_R = 0x02;			// periodic up-counter
	TIMER3_TAPR_R = 250;			// 16MHz/250 64kHz
	TIMER3_TAILR_R = 64000/4;		//1 miliseconds
	TIMER3_ICR_R = 0x01;			// clear Timer3A timeout flag
	TIMER3_IMR_R |= 0x01;			// enable Timer3A timeout interrupt
	TIMER3_CTL_R |= 0x01;			// enable Timer3A after config
	//PRI5[31:29] set interrupt PRIORITY = 4
	NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0x80000000;		// Priority 4

	//NVIC_PRI5_R = (NVIC_PRI5_R & 0x00ffffff)|0xC0000000;		// Priority 6
	NVIC_EN1_R |= 0x00000008;	
	
	
	
	
}

void Timer3A_Handler(void){//1 second
	volatile uint32_t readback;
	TIMER3_ICR_R = 0x01;				
	/*
	UART0_transmit_String("Right RPM: ");
	rpmr = (countr*60*4)/20;
	UART0_transmit_dec(rpmr);
	
	UART0_OutChar('\t');
	UART0_transmit_String("Left RPM: ");
	rpml = (countl*60*4)/20;
	UART0_transmit_dec(rpml);
	
	
	UART0_OutChar('\r');UART0_OutChar('\n');//57600
	//pid();
	countr = 0;
	countl = 0;*/
	readback = TIMER3_ICR_R;
/*	
	if(rpm > rpml){
		speed_reductionl += 200;
	}
	else if(rpm < rpml){
		speed_reductionl -= 200;
	} 
	
	if(rpm > rpmr){
		speed_reductionr += 200;
	}
	else if(rpm < rpmr){
		speed_reductionr -= 200;
	} 
	*/

}	


void Robot_Controller(unsigned char character){
		
	speed_reductionl = 30000;
	speed_reductionr = 30000;

	if (character == 'F')
			{
				rpm =  120;		
				GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |BLUE;
				//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
				GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
				PC4_PWM(39998 - speed_reductionl);
				PC5_PWM(39998 - speed_reductionr);
			}
		else if (character == 'B')
			{
				rpm =  120;
				GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |RED;
				//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x40;
				GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0x50;
				PC4_PWM(39998 - speed_reductionl);
				PC5_PWM(39998 - speed_reductionr);

			}
		else if (character == 'L')
			{
				rpm =  90;
				GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |GREEN;
				//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
				GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
				PC4_PWM(39998);
				PC5_PWM(39998 - speed_reductionr);//right
			}
		else if (character == 'R')
			{
				rpm =  90;
				GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |YELLOW;
				//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
				GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
				PC4_PWM(39998 - speed_reductionl);//left
				PC5_PWM(39998);
			}
		else if(character == 'S')
			{
				rpm =  0;
				GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |PINK;
				//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
				GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
				PC4_PWM(39998);
				PC5_PWM(39998);
			}
		else
		{
			rpm =  0;
			speed_reductionl = 0;
			speed_reductionr = 0;
			GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R& ~0x0E) |SKY_BLUE;
			//GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xC0) | 0x80;
			GPIO_PORTB_DATA_R = (GPIO_PORTB_DATA_R & ~0xF0) | 0xA0;
			PC4_PWM(39998);
			PC5_PWM(39998);
		}
}

void main_init(void){
	DisableInterrupts();
	UART0_INIT();
	UART1_INIT();
	EdgeCounter_Init();
	timer3_Init();
  PORTC_PWM0_GEN3_AB_Init();
	//PortC_Direction_Init();
	PortB_Direction_Init();
	PORTF_INIT();
	EnableInterrupts(); 
	//PC4_PWM(39998);
	//PC5_PWM(39998);
}

